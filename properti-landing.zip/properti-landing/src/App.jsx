import { useState, useEffect } from "react";

const DEFAULT_AGENT = {
  nama: "Nama Anda",
  tagline: "Konsultan Properti · Jakarta & Sekitarnya",
  whatsapp: "6281234567890",
};

const DEFAULT_PROPERTI = [
  {
    id: 1,
    judul: "Rumah Minimalis Jatinegara",
    tipe: "Dijual",
    harga: "Rp 850.000.000",
    lokasi: "Jatinegara, Jakarta Timur",
    lt: "90",
    lb: "70",
    kt: "3",
    km: "2",
    deskripsi: "Rumah 2 lantai kondisi terawat, akses mudah ke jalan utama, dekat sekolah dan pasar.",
    foto: "",
    unggulan: true,
  },
];

const C = {
  bg: "#0f0e0c",
  surface: "#1a1816",
  card: "#211f1c",
  border: "#2e2b27",
  accent: "#c9a96e",
  teks: "#f0ece4",
  muted: "#8a8278",
  green: { bg: "#1a3a2a", teks: "#5ecb8a" },
  blue: { bg: "#1a2a3a", teks: "#5eaaec" },
  danger: "#c06060",
};

function useStorage(key, init) {
  const [val, setVal] = useState(() => {
    try {
      const s = localStorage.getItem(key);
      return s ? JSON.parse(s) : init;
    } catch { return init; }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
  }, [key, val]);
  return [val, setVal];
}

const inpBase = {
  background: "#0f0e0c",
  border: "1px solid #3a3733",
  color: "#f0ece4",
  padding: "9px 12px",
  fontSize: 13,
  fontFamily: "inherit",
  borderRadius: 4,
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
};

function Input({ label, value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, letterSpacing: "0.1em", textTransform: "uppercase" }}>{label}</div>}
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={inpBase} />
    </div>
  );
}

function Textarea({ label, value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, letterSpacing: "0.1em", textTransform: "uppercase" }}>{label}</div>}
      <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3} style={{ ...inpBase, resize: "vertical", lineHeight: 1.6 }} />
    </div>
  );
}

function Select({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <div style={{ fontSize: 11, color: C.muted, marginBottom: 5, letterSpacing: "0.1em", textTransform: "uppercase" }}>{label}</div>}
      <select value={value} onChange={e => onChange(e.target.value)} style={{ ...inpBase, cursor: "pointer" }}>
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, variant = "primary", small }) {
  const s = {
    primary: { background: C.accent, color: "#0f0e0c", border: "none" },
    outline: { background: "transparent", color: C.accent, border: "1px solid " + C.accent },
    danger: { background: "transparent", color: C.danger, border: "1px solid " + C.danger },
    ghost: { background: "transparent", color: C.muted, border: "1px solid " + C.border },
  };
  return (
    <button onClick={onClick} style={{ ...s[variant], padding: small ? "6px 14px" : "10px 20px", fontSize: small ? 12 : 13, fontFamily: "Georgia, serif", cursor: "pointer", borderRadius: 3, letterSpacing: "0.05em" }}>
      {children}
    </button>
  );
}

function FormProperti({ data, onSave, onCancel }) {
  const [f, setF] = useState(data);
  const set = k => v => setF(p => ({ ...p, [k]: v }));
  return (
    <div style={{ background: C.surface, border: "1px solid " + C.border, borderRadius: 6, padding: 24, marginBottom: 16 }}>
      <div style={{ fontSize: 14, color: C.accent, marginBottom: 20 }}>{data.id ? "Edit Properti" : "Tambah Properti Baru"}</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
        <div style={{ gridColumn: "1 / -1" }}><Input label="Judul Properti" value={f.judul} onChange={set("judul")} placeholder="cth: Rumah Minimalis Jatinegara" /></div>
        <Select label="Tipe" value={f.tipe} onChange={set("tipe")} options={["Dijual", "Disewa"]} />
        <Input label="Harga" value={f.harga} onChange={set("harga")} placeholder="cth: Rp 850.000.000" />
        <div style={{ gridColumn: "1 / -1" }}><Input label="Lokasi" value={f.lokasi} onChange={set("lokasi")} placeholder="cth: Jatinegara, Jakarta Timur" /></div>
        <Input label="Luas Tanah (m²)" value={f.lt} onChange={set("lt")} placeholder="90" />
        <Input label="Luas Bangunan (m²)" value={f.lb} onChange={set("lb")} placeholder="70" />
        <Input label="Kamar Tidur" value={f.kt} onChange={set("kt")} placeholder="3" />
        <Input label="Kamar Mandi" value={f.km} onChange={set("km")} placeholder="2" />
        <div style={{ gridColumn: "1 / -1" }}><Textarea label="Deskripsi" value={f.deskripsi} onChange={set("deskripsi")} placeholder="Kondisi, keunggulan, dan akses lokasi..." /></div>
        <div style={{ gridColumn: "1 / -1" }}><Input label="URL Foto (opsional)" value={f.foto} onChange={set("foto")} placeholder="https://..." /></div>
        <div style={{ gridColumn: "1 / -1", display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <input type="checkbox" id="ung" checked={f.unggulan} onChange={e => set("unggulan")(e.target.checked)} style={{ accentColor: C.accent, width: 16, height: 16 }} />
          <label htmlFor="ung" style={{ fontSize: 13, color: C.teks, cursor: "pointer" }}>Tandai sebagai properti unggulan</label>
        </div>
      </div>
      <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
        <Btn onClick={() => onSave(f)}>Simpan</Btn>
        <Btn variant="ghost" onClick={onCancel}>Batal</Btn>
      </div>
    </div>
  );
}

function AdminPanel({ agent, setAgent, properti, setProperti, onKeluar }) {
  const [editAgent, setEditAgent] = useState(false);
  const [formAgent, setFormAgent] = useState(agent);
  const [editId, setEditId] = useState(null);
  const [tambahBaru, setTambahBaru] = useState(false);
  const emptyP = { judul: "", tipe: "Dijual", harga: "", lokasi: "", lt: "", lb: "", kt: "", km: "", deskripsi: "", foto: "", unggulan: false };

  function simpanAgent() { setAgent(formAgent); setEditAgent(false); }
  function simpanProperti(data) {
    if (data.id) setProperti(p => p.map(x => x.id === data.id ? data : x));
    else setProperti(p => [...p, { ...data, id: Date.now() }]);
    setEditId(null); setTambahBaru(false);
  }
  function hapus(id) { if (window.confirm("Hapus properti ini?")) setProperti(p => p.filter(x => x.id !== id)); }

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "Georgia, serif", color: C.teks }}>
      <div style={{ background: C.surface, borderBottom: "1px solid " + C.border, padding: "16px 28px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <span style={{ fontSize: 11, letterSpacing: "0.2em", color: C.accent, textTransform: "uppercase" }}>Mode Edit</span>
          <div style={{ fontSize: 17, marginTop: 2 }}>Panel Kelola Properti</div>
        </div>
        <Btn variant="outline" onClick={onKeluar}>← Lihat Landing Page</Btn>
      </div>
      <div style={{ maxWidth: 780, margin: "0 auto", padding: "36px 24px" }}>
        <div style={{ marginBottom: 40 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontSize: 13, letterSpacing: "0.15em", color: C.accent, textTransform: "uppercase" }}>Data Agen</div>
            {!editAgent && <Btn small variant="outline" onClick={() => { setFormAgent(agent); setEditAgent(true); }}>Edit</Btn>}
          </div>
          {editAgent ? (
            <div style={{ background: C.surface, border: "1px solid " + C.border, borderRadius: 6, padding: 24 }}>
              <Input label="Nama Agen" value={formAgent.nama} onChange={v => setFormAgent(p => ({ ...p, nama: v }))} />
              <Input label="Tagline" value={formAgent.tagline} onChange={v => setFormAgent(p => ({ ...p, tagline: v }))} />
              <Input label="Nomor WhatsApp (format: 628xxx)" value={formAgent.whatsapp} onChange={v => setFormAgent(p => ({ ...p, whatsapp: v }))} placeholder="628123456789" />
              <div style={{ display: "flex", gap: 10, marginTop: 8 }}><Btn onClick={simpanAgent}>Simpan</Btn><Btn variant="ghost" onClick={() => setEditAgent(false)}>Batal</Btn></div>
            </div>
          ) : (
            <div style={{ background: C.surface, border: "1px solid " + C.border, borderRadius: 6, padding: 20 }}>
              <div style={{ fontSize: 16, marginBottom: 4 }}>{agent.nama}</div>
              <div style={{ fontSize: 13, color: C.muted, marginBottom: 4 }}>{agent.tagline}</div>
              <div style={{ fontSize: 13, color: C.muted }}>WA: {agent.whatsapp}</div>
            </div>
          )}
        </div>
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div style={{ fontSize: 13, letterSpacing: "0.15em", color: C.accent, textTransform: "uppercase" }}>Daftar Properti ({properti.length})</div>
            {!tambahBaru && <Btn small onClick={() => { setTambahBaru(true); setEditId(null); }}>+ Tambah Properti</Btn>}
          </div>
          {tambahBaru && <FormProperti data={emptyP} onSave={simpanProperti} onCancel={() => setTambahBaru(false)} />}
          {properti.length === 0 && !tambahBaru && (
            <div style={{ textAlign: "center", color: C.muted, padding: "40px 0", fontSize: 14 }}>Belum ada properti. Klik "+ Tambah Properti".</div>
          )}
          {properti.map(p => (
            <div key={p.id}>
              {editId === p.id ? (
                <FormProperti data={p} onSave={simpanProperti} onCancel={() => setEditId(null)} />
              ) : (
                <div style={{ background: C.surface, border: "1px solid " + C.border, borderRadius: 6, padding: 18, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 15 }}>{p.judul}</span>
                      <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 2, background: p.tipe === "Dijual" ? C.green.bg : C.blue.bg, color: p.tipe === "Dijual" ? C.green.teks : C.blue.teks }}>{p.tipe}</span>
                      {p.unggulan && <span style={{ fontSize: 10, color: C.accent, border: "1px solid " + C.accent, padding: "2px 6px", borderRadius: 2 }}>Unggulan</span>}
                    </div>
                    <div style={{ fontSize: 13, color: C.muted }}>{p.lokasi} · {p.harga}</div>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
                    <Btn small variant="outline" onClick={() => { setEditId(p.id); setTambahBaru(false); }}>Edit</Btn>
                    <Btn small variant="danger" onClick={() => hapus(p.id)}>Hapus</Btn>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function KartuProperti({ p, onHubungi }) {
  const [hover, setHover] = useState(false);
  return (
    <div style={{ background: hover ? "#272420" : C.card, overflow: "hidden", transition: "background 0.2s" }} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      {p.foto ? (
        <img src={p.foto} alt={p.judul} style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", display: "block" }} />
      ) : (
        <div style={{ width: "100%", aspectRatio: "4/3", background: "linear-gradient(135deg, " + C.surface + ", " + C.border + ")", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40 }}>🏠</div>
      )}
      <div style={{ padding: "20px 22px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
          <span style={{ fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", padding: "3px 10px", background: p.tipe === "Dijual" ? C.green.bg : C.blue.bg, color: p.tipe === "Dijual" ? C.green.teks : C.blue.teks, borderRadius: 2 }}>{p.tipe}</span>
          {p.unggulan && <span style={{ fontSize: 10, color: C.accent, border: "1px solid " + C.accent, padding: "2px 8px", borderRadius: 2 }}>Unggulan</span>}
        </div>
        <div style={{ fontSize: 17, marginBottom: 4, lineHeight: 1.3 }}>{p.judul}</div>
        <div style={{ fontSize: 12, color: C.muted, marginBottom: 12 }}>📍 {p.lokasi}</div>
        <div style={{ fontSize: 20, color: C.accent, marginBottom: 12 }}>{p.harga}</div>
        <div style={{ display: "flex", gap: 14, fontSize: 12, color: C.muted, marginBottom: 14, flexWrap: "wrap" }}>
          {p.lt && <span>LT {p.lt} m²</span>}
          {p.lb && <span>LB {p.lb} m²</span>}
          {p.kt && <span>{p.kt} KT</span>}
          {p.km && <span>{p.km} KM</span>}
        </div>
        <div style={{ fontSize: 13, color: C.muted, lineHeight: 1.6, marginBottom: 16 }}>{p.deskripsi}</div>
        <button onClick={() => onHubungi(p)} style={{ fontSize: 12, color: hover ? "#0f0e0c" : C.accent, letterSpacing: "0.1em", textTransform: "uppercase", cursor: "pointer", background: hover ? C.accent : "transparent", border: "1px solid " + C.accent, padding: "9px 16px", fontFamily: "Georgia, serif", width: "100%", transition: "background 0.2s, color 0.2s" }}>
          Tanyakan Properti Ini
        </button>
      </div>
    </div>
  );
}

function LandingPage({ agent, properti, onAdmin }) {
  function waLink(pesan) { return "https://wa.me/" + agent.whatsapp + "?text=" + encodeURIComponent(pesan); }
  function hubungi(p) {
    const pesan = p
      ? "Halo Pak " + agent.nama + ", saya tertarik dengan properti *" + p.judul + "* (" + p.harga + ") di " + p.lokasi + ". Boleh saya minta info lebih lanjut?"
      : "Halo Pak " + agent.nama + ", saya ingin menanyakan properti yang tersedia. Boleh dibantu?";
    window.open(waLink(pesan), "_blank");
  }
  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "Georgia, serif", color: C.teks }}>
      <div style={{ position: "fixed", bottom: 20, right: 20, zIndex: 200 }}>
        <button onClick={onAdmin} style={{ background: C.surface, border: "1px solid " + C.border, color: C.muted, padding: "8px 14px", fontSize: 11, cursor: "pointer", borderRadius: 4, fontFamily: "inherit", letterSpacing: "0.1em" }}>⚙ Edit</button>
      </div>
      <nav style={{ borderBottom: "1px solid " + C.border, padding: "18px 32px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: C.bg, zIndex: 100 }}>
        <div style={{ fontSize: 18, letterSpacing: "0.15em", color: C.accent, textTransform: "uppercase" }}>Properti Jakarta</div>
        <div style={{ fontSize: 13, color: C.muted }}>{agent.nama}</div>
      </nav>
      <section style={{ padding: "80px 32px 60px", maxWidth: 900, margin: "0 auto", textAlign: "center" }}>
        <span style={{ fontSize: 11, letterSpacing: "0.3em", color: C.accent, textTransform: "uppercase", display: "block", marginBottom: 20 }}>Properti Terpercaya</span>
        <h1 style={{ fontSize: "clamp(32px, 5vw, 54px)", fontWeight: "normal", lineHeight: 1.15, marginBottom: 18 }}>Temukan Properti<br />Impian Anda</h1>
        <p style={{ fontSize: 16, color: C.muted, lineHeight: 1.7, maxWidth: 480, margin: "0 auto 32px" }}>{agent.tagline}<br />Hubungi kami untuk survei dan negosiasi harga.</p>
        <button onClick={() => hubungi(null)} style={{ background: C.accent, color: "#0f0e0c", border: "none", padding: "14px 28px", fontSize: 14, fontFamily: "Georgia, serif", cursor: "pointer", letterSpacing: "0.08em", fontWeight: "bold" }}>
          💬 &nbsp; Konsultasi via WhatsApp
        </button>
      </section>
      <hr style={{ border: "none", borderTop: "1px solid " + C.border, margin: "0 32px" }} />
      <section style={{ padding: "56px 32px", maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ marginBottom: 36 }}>
          <span style={{ fontSize: 11, letterSpacing: "0.3em", color: C.accent, textTransform: "uppercase", display: "block", marginBottom: 8 }}>Tersedia Sekarang</span>
          <h2 style={{ fontSize: 26, fontWeight: "normal", margin: 0 }}>{properti.length} Properti Pilihan</h2>
        </div>
        {properti.length === 0 ? (
          <div style={{ textAlign: "center", color: C.muted, padding: "60px 0", fontSize: 15 }}>Belum ada properti. Klik tombol ⚙ Edit di pojok kanan bawah.</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 1, background: C.border, border: "1px solid " + C.border }}>
            {properti.map(p => <KartuProperti key={p.id} p={p} onHubungi={hubungi} />)}
          </div>
        )}
      </section>
      <hr style={{ border: "none", borderTop: "1px solid " + C.border, margin: "0 32px" }} />
      <section style={{ padding: "56px 32px", maxWidth: 560, margin: "0 auto", textAlign: "center" }}>
        <span style={{ fontSize: 11, letterSpacing: "0.3em", color: C.accent, textTransform: "uppercase", display: "block", marginBottom: 12 }}>Hubungi Agen</span>
        <h2 style={{ fontSize: 24, fontWeight: "normal", marginBottom: 12 }}>{agent.nama}</h2>
        <p style={{ color: C.muted, fontSize: 14, marginBottom: 28, lineHeight: 1.6 }}>{agent.tagline}</p>
        <button onClick={() => hubungi(null)} style={{ background: C.accent, color: "#0f0e0c", border: "none", padding: "13px 28px", fontSize: 14, fontFamily: "Georgia, serif", cursor: "pointer", letterSpacing: "0.08em", fontWeight: "bold" }}>
          💬 &nbsp; Hubungi via WhatsApp
        </button>
      </section>
      <footer style={{ borderTop: "1px solid " + C.border, padding: "22px 32px", textAlign: "center", fontSize: 12, color: C.muted }}>
        © {new Date().getFullYear()} {agent.nama} · Pemasaran Properti Jakarta
      </footer>
    </div>
  );
}

export default function App() {
  const [agent, setAgent] = useStorage("prop_agent", DEFAULT_AGENT);
  const [properti, setProperti] = useStorage("prop_list", DEFAULT_PROPERTI);
  const [mode, setMode] = useState("landing");
  if (mode === "admin") return <AdminPanel agent={agent} setAgent={setAgent} properti={properti} setProperti={setProperti} onKeluar={() => setMode("landing")} />;
  return <LandingPage agent={agent} properti={properti} onAdmin={() => setMode("admin")} />;
}
